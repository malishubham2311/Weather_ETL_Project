import os
import requests
import pandas as pd
import numpy as np
from typing import Dict, Tuple
from dotenv import load_dotenv

from dagster import asset, Definitions, Output, MetadataValue
from sqlalchemy import create_engine, text
from pymongo import MongoClient
from pymongo.errors import ServerSelectionTimeoutError

# Load environment variables from .env file
load_dotenv()



# OPEN-METEO API CONFIG

LAT = 53.34
LON = -6.26
START_DATE = "2023-01-01"
END_DATE = "2023-12-31"
BASE_URL = "https://archive-api.open-meteo.com/v1/archive"

DATASETS = {
    "solar": [
        "temperature_2m", "precipitation", "cloud_cover", "cloud_cover_low",
        "shortwave_radiation", "direct_radiation", "diffuse_radiation", "wind_speed_10m"
    ],
    "agri": [
        "soil_temperature_0cm", "soil_temperature_18cm",
        "soil_moisture_0_to_1cm", "soil_moisture_3_to_9cm",
        "rain", "et0_fao_evapotranspiration", "vapor_pressure_deficit"
    ],
    "marine": [
        "pressure_msl", "surface_pressure", "temperature_2m",
        "wind_speed_10m", "wind_speed_100m",
        "wind_direction_100m", "wind_gusts_10m"
    ],
}

ERROR_CODES = {-9999, -999, 9999}



# POSTGRES CONFIG (env vars)

PG_HOST = os.getenv("PG_HOST", "127.0.0.1")
PG_PORT = os.getenv("PG_PORT", "5432")
PG_USER = os.getenv("PG_USER", "etl_user")
PG_PASSWORD = os.getenv("PG_PASSWORD", "StrongPass123!")
PG_DB   = os.getenv("PG_DB", "weather_demo")

PG_URL = f"postgresql+psycopg2://{PG_USER}:{PG_PASSWORD}@{PG_HOST}:{PG_PORT}/{PG_DB}"
engine = create_engine(PG_URL, pool_pre_ping=True)



# MONGODB ATLAS CONFIG (env vars)

MONGO_URL = os.getenv("MONGO_URL")
MONGO_DB = os.getenv("MONGO_DB", "weather_analytics")

# Initialize MongoDB client
mongo_client = None
if MONGO_URL:
    try:
        mongo_client = MongoClient(MONGO_URL, serverSelectionTimeoutMS=10000)
        # Test connection
        mongo_client.admin.command('ping')
        print(" MongoDB Atlas connection successful")
    except ServerSelectionTimeoutError as e:
        print(f" MongoDB connection timeout: {e}")
        mongo_client = None
    except Exception as e:
        print(f"MongoDB connection error: {type(e).__name__}: {e}")
        mongo_client = None
else:
    print("⚠ MONGO_URL not set in environment")



# DATA QUALITY THRESHOLDS

EMPTY_THRESHOLD = 0.95  # Drop columns with >95% missing
OUTLIER_IQR_MULTIPLIER = 3.0  # Conservative outlier detection



def fetch_openmeteo_json(hourly_vars: list[str]) -> dict:
    """Fetch weather data from Open-Meteo API"""
    params = {
        "latitude": LAT,
        "longitude": LON,
        "start_date": START_DATE,
        "end_date": END_DATE,
        "hourly": ",".join(hourly_vars),
        "timezone": "auto",
    }
    r = requests.get(BASE_URL, params=params, timeout=60)
    r.raise_for_status()
    return r.json()


def log_data_quality(df: pd.DataFrame, dataset_name: str, stage: str) -> Dict:
    """Track data quality metrics"""
    numeric_cols = df.select_dtypes(include='number').columns.tolist()
    
    quality_report = {
        "dataset": dataset_name,
        "stage": stage,
        "total_rows": len(df),
        "total_columns": len(df.columns),
        "numeric_columns": len(numeric_cols),
        "missing_cells": df.isnull().sum().sum(),
        "missing_percentage": round(df.isnull().sum().sum() / (len(df) * len(df.columns)) * 100, 2),
        "duplicate_rows": df.duplicated().sum(),
    }

    
    return quality_report


def remove_empty_columns(df: pd.DataFrame, threshold: float = EMPTY_THRESHOLD) -> Tuple[pd.DataFrame, list]:
    """Remove columns that are mostly empty"""
    missing_pct = df.isnull().sum() / len(df)
    cols_to_drop = missing_pct[missing_pct > threshold].index.tolist()
    
    if cols_to_drop:
        df = df.drop(columns=cols_to_drop)
    
    return df, cols_to_drop




def simple_imputation(df: pd.DataFrame) -> pd.DataFrame:
    """
    Applying imputation for missing values. There can be various strategies:
    1. Time-based interpolation (already done earlier)
    2. Forward fill + Backward fill for remaining gaps
    3. Mean substitution as backup
    """
    numeric_cols = df.select_dtypes(include='number').columns.tolist()
    
    # Check if imputation is needed
    missing_counts = df[numeric_cols].isnull().sum()
    cols_with_missing = missing_counts[missing_counts > 0].index.tolist()
    
    if not cols_with_missing:
        return df
    
    
    # Step 1: Forward/Backward fill (time-series continuity)
    df[numeric_cols] = df[numeric_cols].ffill().bfill()
    
    # Step 2: Mean substitution for any remaining NaNs (edge cases)
    remaining_nulls = df[numeric_cols].isnull().sum()
    cols_still_missing = remaining_nulls[remaining_nulls > 0].index.tolist()
    
    if cols_still_missing:
        print(f"   Applying mean substitution to {len(cols_still_missing)} columns")
        for col in cols_still_missing:
            df[col] = df[col].fillna(df[col].mean())
    
    return df





def json_hourly_to_df(payload: dict, dataset_name: str) -> pd.DataFrame:
    """
    Transform JSON API response to cleaned DataFrame with preprocessing
    """
    hourly = payload.get("hourly", {})
    if "time" not in hourly:
        raise ValueError(f"Invalid API response for {dataset_name}. Keys: {list(payload.keys())}")


    # Initial DataFrame creation
    df = pd.DataFrame(hourly)

    # Parse time safely + keep consistent ordering
    df["time"] = pd.to_datetime(df["time"], errors="coerce")
    df = df.dropna(subset=["time"]).sort_values("time").reset_index(drop=True)

    log_data_quality(df, dataset_name, "Raw")

    # Replace API error codes with NaN
    for col in df.columns:
        if col != "time":
            df[col] = df[col].where(~df[col].isin(ERROR_CODES), np.nan)

    # Remove columns with excessive missing data
    df, dropped_cols = remove_empty_columns(df)

    # Remove duplicate rows
    before_dedup = len(df)
    df = df.drop_duplicates(subset=["time"], keep="first")
    if len(df) < before_dedup:
        print(f"   Dropped {before_dedup - len(df)} duplicate rows in {dataset_name}")

    # Apply time-aware interpolation (REQUIRES DatetimeIndex)
    # Coerce non-numeric columns to numeric when possible
    for col in df.columns:
        if col != "time":
            df[col] = pd.to_numeric(df[col], errors="coerce")

    numeric_cols = [c for c in df.columns if c != "time"]

    df = df.set_index("time").sort_index()
    df[numeric_cols] = df[numeric_cols].interpolate(method="time", limit_direction="both")
    df = df.reset_index()

    # Apply simple imputation for remaining gaps (forward/backward fill + mean)
    df = simple_imputation(df)

    # Add feature engineering columns
    df["month_name"] = df["time"].dt.month_name()
    df["hour"] = df["time"].dt.hour
    df["day_of_week"] = df["time"].dt.day_name()
    df["is_weekend"] = df["time"].dt.dayofweek.isin([5, 6]).astype(int)

    log_data_quality(df, dataset_name, "Clean")

    return df


def ensure_table_and_write(df: pd.DataFrame, table_name: str):
    """Write DataFrame to PostgreSQL with indexes"""
    # if "time" not in df.columns:
    #     raise ValueError(f"{table_name}: missing 'time' column.")
    
    df.to_sql(
        table_name, 
        engine, 
        if_exists="replace", 
        index=False, 
        method="multi", 
        chunksize=5000
    )
    
    # Create performance indexes
    with engine.begin() as conn:
        conn.execute(text(f'CREATE INDEX IF NOT EXISTS idx_{table_name}_time ON "{table_name}" ("time");'))
        if "month_name" in df.columns:
            conn.execute(text(f'CREATE INDEX IF NOT EXISTS idx_{table_name}_month ON "{table_name}" ("month_name");'))
    

def write_to_mongodb(df: pd.DataFrame, collection_name: str) -> bool:
    """Write DataFrame to MongoDB Atlas collection"""
    if not mongo_client:
        return False
    
    try:
        db = mongo_client[MONGO_DB]
        collection = db[collection_name]
        
        # Convert DataFrame to list of dictionaries
        records = df.replace({pd.NaT: None, np.nan: None}).to_dict('records')
        
        # Convert datetime objects to ISO format strings for better MongoDB compatibility
        for record in records:
            if 'time' in record and pd.notna(record['time']):
                record['time'] = pd.Timestamp(record['time']).isoformat()
        
        # Drop existing collection and insert new data
        collection.drop()
        if records:
            result = collection.insert_many(records)


            # Create index on time field for better query performance
            collection.create_index('time')
            return True
        else:
            return False
            
    except Exception as e:
        print(f"   ✗ Error writing to MongoDB collection '{collection_name}': {e}")
        return False
    

"""Since this is a small dataset we merged tables using pandas else we could have used SQL joins."""

def build_fact_weather(solar: pd.DataFrame, agri: pd.DataFrame, marine: pd.DataFrame) -> pd.DataFrame:
    """Create unified fact table for analytics"""
    
    # Outer join to preserve all time periods
    df = solar.merge(
        agri, 
        on=["time", "month_name", "hour", "day_of_week", "is_weekend"], 
        how="outer", 
        suffixes=("_solar", "_agri")
    )
    
    df = df.merge(
        marine, 
        on=["time", "month_name", "hour", "day_of_week", "is_weekend"], 
        how="outer", 
        suffixes=("", "_marine")
    )
    
    df = df.sort_values("time").reset_index(drop=True)
    
    # Final pass: ensure no nulls introduced during merge
    numeric_cols = df.select_dtypes(include='number').columns
    df[numeric_cols] = df[numeric_cols].ffill().bfill()
    
    # Mean substitution for any remaining edge case nulls
    for col in numeric_cols:
        if df[col].isnull().any():
            df[col] = df[col].fillna(df[col].mean())
    
    
    return df


# DAGSTER ASSETS
@asset
def openmeteo_raw() -> dict:
    """Fetch raw JSON data from Open-Meteo API"""
    raw_data = {}
    
    for name, vars_ in DATASETS.items():
        try:
            raw_data[name] = fetch_openmeteo_json(vars_)
        except Exception as e:
            raise ValueError(f"Failed to fetch {name}: {e}")
    
    return raw_data


@asset
def openmeteo_tables(openmeteo_raw: dict) -> dict:
    """Transform: Clean and preprocess raw JSON into structured tables"""
    cleaned_tables = {}
    quality_reports = []
    
    for name, payload in openmeteo_raw.items():
        try:
            df = json_hourly_to_df(payload, name)
            cleaned_tables[name] = df
            quality_reports.append({
                "dataset": name,
                "rows": len(df),
                "columns": len(df.columns),
                "null_cells": df.isnull().sum().sum()
            })
        except Exception as e:
            raise ValueError(f"Failed to process {name}: {e}")
    
  
    for report in quality_reports:
        print(f"   {report['dataset']}: {report['rows']:,} rows, {report['columns']} cols, {report['null_cells']} nulls")
    
    return cleaned_tables


@asset
def postgres_load(openmeteo_tables: dict) -> Output[str]:
    """Write cleaned data to PostgreSQL and MongoDB Atlas"""
    
    pg_tables_written = []
    mongo_collections_written = []
    
    # Write individual domain tables to both PostgreSQL and MongoDB
    for name, df in openmeteo_tables.items():
        if df is None or df.empty:
            raise ValueError(f"{name} is empty or None")
        
        # PostgreSQL
        ensure_table_and_write(df, name)
        pg_tables_written.append(name)
        
        # MongoDB
        if write_to_mongodb(df, name):
            mongo_collections_written.append(name)
    
    # Create unified fact table for analytics
    fact = build_fact_weather(
        openmeteo_tables["solar"],
        openmeteo_tables["agri"],
        openmeteo_tables["marine"],
    )
    
    # PostgreSQL
    ensure_table_and_write(fact, "fact_weather")
    pg_tables_written.append("fact_weather")
    
    # MongoDB
    if write_to_mongodb(fact, "fact_weather"):
        mongo_collections_written.append("fact_weather")
    
    metadata_text = f"PostgreSQL: {', '.join(pg_tables_written)}"
    if mongo_collections_written:
        metadata_text += f" | MongoDB: {', '.join(mongo_collections_written)}"
    
    return Output(
        value="ETL Complete - All data loaded to PostgreSQL and MongoDB Atlas",
        metadata={
            "postgres_tables": len(pg_tables_written),
            "mongodb_collections": len(mongo_collections_written),
            "table_names": MetadataValue.text(metadata_text),
            "total_records": MetadataValue.int(len(fact)),
            "postgres_database": MetadataValue.text(f"{PG_DB}@{PG_HOST}"),
            "mongodb_database": MetadataValue.text(MONGO_DB if mongo_client else "Not Connected"),
        }
    )


defs = Definitions(assets=[openmeteo_raw, openmeteo_tables, postgres_load])
