from sqlalchemy import create_engine, text
import os

PG_HOST = os.getenv("PG_HOST", "127.0.0.1")
PG_PORT = os.getenv("PG_PORT", "5432")
PG_USER = os.getenv("PG_USER", "etl_user")
PG_PASSWORD = os.getenv("PG_PASSWORD", "StrongPass123!")
PG_DB = os.getenv("PG_DB", "weather_demo")

PG_URL = f"postgresql+psycopg2://{PG_USER}:{PG_PASSWORD}@{PG_HOST}:{PG_PORT}/{PG_DB}"

try:
    engine = create_engine(PG_URL)
    with engine.connect() as conn:
        result = conn.execute(text("SELECT version();"))
        print("PostgreSQL connection successful!")
        print(f"   Version: {result.fetchone()[0]}")
except Exception as e:
    print(f"Connection failed: {e}")
